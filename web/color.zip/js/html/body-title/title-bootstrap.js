const title = `
<br><br>
<div class="title">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 col-sm-12">
                <hr class="bg-primary">
                <h1>Bootstrap</h1>
                <p>Great Bootstrap Themes</p>
                <a class="btn btn-primary" href="">Get Started</a>
            </div>
            <div class="col-md-6 col-sm-12">
                <img src="../img/undraw_web_developer_p3e5.svg">
            </div>
        </div>
    </div>
</div>`;
document.getElementById("title").innerHTML += title;