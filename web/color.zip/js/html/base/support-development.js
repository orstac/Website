const support = `    
<div class="support supporthtml">
    <div class="container">
        <h2>Want a custom Setup?</h2>
        <p>Use <kbd>-new</kbd> on our discord server to get a setup!</p>
        <a href="https://discord.gg/SsS5VcS" class="btn btn-success discord"><i class="fab fa-discord"></i> Join Our
            Discord</a>
    </div>
</div>`;
document.getElementById("support").innerHTML += support;