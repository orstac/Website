[colors](https://flatuicolors.com/palette/us)

main colors
- #0984e3